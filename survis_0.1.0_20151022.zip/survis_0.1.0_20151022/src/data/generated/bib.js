﻿define({ entries : {
    "castillo2003learning": {
        "author": "Castillo, Lourdes Pena and Wrobel, Stefan",
        "booktitle": "INTERNATIONAL JOINT CONFERENCE ON ARTIFICIAL INTELLIGENCE",
        "keywords": "type:learning system, Minesweeper, Greedy Search, Macros, Active Inductive Learning",
        "organization": "LAWRENCE ERLBAUM ASSOCIATES LTD ,",
        "pages": "533--540",
        "title": "Learning minesweeper with multirelational learning",
        "type": "inproceedings",
        "volume": "18",
        "year": "2003"
    },
    "golan2011minesweeper": {
        "author": "Golan, Shahar",
        "journal": "Applied mathematics and computation",
        "keywords": "type:Minesweeper, Counting problem, Consistency, Treewidth, Constraint satisfaction, CSP, Generating polynomials, Dynamic programming",
        "number": "14",
        "pages": "6616--6623",
        "publisher": "Elsevier ,",
        "title": "Minesweeper on graphs",
        "type": "article",
        "volume": "217",
        "year": "2011"
    },
    "golan2014minesweeper": {
        "author": "Golan, Shahar",
        "journal": "Applied Mathematics and Computation",
        "keywords": "type:Graph theory, Strategy, Probability, Algorithm, Games, Minesweeper",
        "pages": "292--302",
        "publisher": "Elsevier ,",
        "title": "Minesweeper strategy for one mine",
        "type": "article",
        "volume": "232",
        "year": "2014"
    },
    "kaye2000minesweeper": {
        "author": "Kaye, Richard",
        "journal": "Mathematical Intelligencer",
        "keywords": "type:Minesweeper, NP-completeness, NP",
        "number": "2",
        "pages": "9--15",
        "title": "Minesweeper is NP-complete",
        "type": "article",
        "volume": "22",
        "year": "2000 ,"
    },
    "liu2022solver": {
        "author": "Liu, Chang and Huang, Shunqi and Naying, Gao and Khalid, Mohd Nor Akmal and Iida, Hiroyuki",
        "journal": "Knowledge-Based Systems",
        "keywords": "type:Single-agent game, Stochastic puzzle, Minesweeper, Constraint satisfaction problems, Gauss\u2013Jordan elimination",
        "pages": "108630",
        "publisher": "Elsevier ,",
        "title": "A solver of single-agent stochastic puzzle: A case study with Minesweeper",
        "type": "article",
        "volume": "246",
        "year": "2022"
    },
    "olivianp": {
        "author": "Olivia, Thea ,",
        "keywords": "type:NP-Completeness Theory, Minesweeper, Flood-Fill",
        "title": "NP-Completeness TheoryImplementations in Minesweeper Problems",
        "type": "article"
    },
    "scott2011minesweeper": {
        "author": "Scott, Allan and Stege, Ulrike and Van Rooij, Iris",
        "journal": "The Mathematical Intelligencer",
        "keywords": "type:Minesweeper, NP-complete, co-NP, NP problem class",
        "pages": "5--17",
        "publisher": "Springer",
        "title": "Minesweeper may not be NP-complete but is hard nonetheless",
        "type": "article",
        "volume": "33",
        "year": "2011"
    },
    "studholme2000minesweeper": {
        "author": "Studholme, Chris",
        "journal": "Unpublished project report",
        "keywords": "type:Constraint Satisfaction Problem, Minesweeper, PGMS, CSPStrategy",
        "title": "Minesweeper as a constraint satisfaction problem",
        "type": "article",
        "year": "2000 ,"
    },
    "tu2017exploring": {
        "author": "Tu, Jinzheng and Li, Tianhong and Chen, Shiteng and Zu, Chong and Gu, Zhaoquan",
        "booktitle": "Workshops at the Thirty-First AAAI Conference on Artificial Intelligence",
        "keywords": "type:Minesweeper, Heuristic Strategies, Quasi-optimal Strategies",
        "title": "Exploring efficient strategies for minesweeper",
        "type": "inproceedings",
        "year": "2017 ,"
    },
    "zhang2014optimization": {
        "author": "Zhang, Shiwei and Wang, Hanshi and Liu, Lizhen and Du, Chao and Lu, Jingli",
        "booktitle": "Proceedings of 2014 International Conference on Cloud Computing and Internet of Things",
        "keywords": "type:Algorithm, Neural Network, Back Propagation, Minesweeper",
        "organization": "IEEE ,",
        "pages": "203--207",
        "title": "Optimization of neural network based on genetic algorithm and BP",
        "type": "inproceedings",
        "year": "2014"
    }
}});